package com.rusal.gou.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import javax.persistence.*;
import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

/**
 * Entity
 * @@Column - имя колонки в таблице
 * @@Transient - пропуск переменной из запроса
 */
@Data
@Entity
@Table(schema = "gou_data", name = "filter_ref")
public class FilterEntity {
    @Id
    private Integer id;
    private String name;
    @Column(name = "thread_id")
    private Integer threadId;
    @Column(name = "row_id")
    private Integer rowId;
    private Integer seq;
    @Column(name = "parent_id")
    private Integer parentId;
    @Column(name = "type_id")
    private Integer typeId;
    @Transient private TypeFilterEntity type;
    @Transient private Set<SeamEntity> seam = new TreeSet<>(Comparator.comparing(SeamEntity::getId));
}
