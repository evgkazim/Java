package com.rusal.gou;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GouApplication {
	public static void main(String[] args) {
		SpringApplication.run(GouApplication.class, args);
	}
}
