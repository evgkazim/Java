package com.rusal.gou.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.rusal.gou.auth.EtcAuth;
import com.rusal.gou.auth.TokenUser;
import com.rusal.gou.entity.CellEntity;
import com.rusal.gou.model.Sgou;
import com.rusal.gou.repository.CellRepository;
import com.rusal.gou.service.CellService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@CrossOrigin(originPatterns = "*", allowCredentials = "true")
@RequestMapping(path = "/cell", produces = "application/json")
public class CellController {
    @Autowired private Sgou sgou;
    @Autowired private CellRepository repo;

    @EtcAuth(roles = {"VIEW", "ADMIN"})
    @GetMapping
    public Object select(TokenUser user, @RequestParam Map<String, String> param) {
        return new CellService().select(repo, param);
    }

    @EtcAuth(roles = {"VIEW", "ADMIN"})
    @PostMapping
    public Object update(TokenUser user, @RequestBody CellEntity body) {
        return new CellService().update(repo, user, body, sgou);
    }

    @EtcAuth(roles = {"ADMIN"})
    @DeleteMapping
    public Object delete(TokenUser user, @RequestBody CellEntity body) {
        return new CellService().delete(repo, body, sgou);
    }
}