package com.rusal.gou.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.*;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

import static javax.persistence.GenerationType.IDENTITY;

@Slf4j
@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@JsonPropertyOrder({"id", "filter_id", "row_id1", "row_id2", "operation", "value", "date", "user"})
@Table(schema = "gou_data", name = "cell_state")
public class CellEntity {
    @Id
    @GeneratedValue(strategy = IDENTITY)
    private Integer id;
    @Column(name = "filter_id")
    @JsonProperty(value = "filter_id")
    private Integer filterId;
    @Column(name = "row_id1")
    @JsonProperty(value = "row_id1")
    private Integer rowId1;
    @Column(name = "row_id2")
    @JsonProperty(value = "row_id2")
    private Integer rowId2;
    @Column(name = "oper")
    private String operation;
    @Column(name = "date_trunc")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDate date;
    @Column(name = "val")
    private Integer value;
    @Column(name = "user_name")
    private String user;
    @Transient
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private int x1, y1, x2, y2;
    @Transient
    private String status;
    @Transient
    private String message;

    public CellEntity(String status, String message) {
        this.status = status;
        this.message = message;
    }

    public CellEntity(int rowId1, int rowId2, CellEntity entity, String user) {
        this.filterId = entity.getFilterId();
        this.rowId1 = rowId1;
        this.rowId2 = rowId2;
        this.operation = entity.getOperation();
        this.value = entity.getValue();
        this.date = entity.getDate();
        this.user = user;
        this.status = "ok";
    }

    public CellEntity(int rowId1, int rowId2, CellEntity entity, String user, String operation, int value) {
        this.filterId = entity.getFilterId();
        this.rowId1 = rowId1;
        this.rowId2 = rowId2;
        this.operation = operation;
        this.value = value;
        this.date = entity.getDate();
        this.user = user;
        this.status = "ok";
    }

    public CellEntity(int rowId1, int rowId2, CellEntity entity, String status, String message) {
        this.id = entity.getId();
        this.filterId = entity.getFilterId();
        this.rowId1 = rowId1;
        this.rowId2 = rowId2;
        this.operation = entity.getOperation();
        this.value = entity.getValue();
        this.date = entity.getDate();
        this.user = entity.getUser();
        this.status = status;
        this.message = message;
    }
}
