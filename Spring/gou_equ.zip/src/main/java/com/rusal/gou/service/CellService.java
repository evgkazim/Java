package com.rusal.gou.service;

import com.google.gson.Gson;
import com.rusal.gou.auth.TokenUser;
import com.rusal.gou.entity.CellEntity;
import com.rusal.gou.model.Sgou;
import com.rusal.gou.repository.CellRepository;
import com.rusal.gou.utils.ObjectToJson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Класс сервис для таблицы <b>gou_data.cell_state<b/>.
 * @autor Evgeny Kazimov
 * @version 1.0
 */

@Slf4j
@Service
public class CellService {

    public Object select(CellRepository repo, Map<String, String> param) {
        try {
            List<CellEntity> entities = repo.findByParam(param.get("id"), param.get("date"));
            log.debug("Debug in method \"{}\", param - {}!", "select", param);
            return ResponseEntity.ok().body(ObjectToJson.toJson(calc(entities)));
        } catch (Exception ex) {
            log.error("Error in method \"{}\", type error - {}!", "select", ex.toString());
            return ResponseEntity.internalServerError().body(new Gson().toJson(ex));
        }
    }

    public Object update(CellRepository repo, TokenUser user, CellEntity body, Sgou sgou) {
        try {
            if (!sgou.isFilter(body.getFilterId()))
                return ResponseEntity.ok().body(ObjectToJson.toJson(new CellEntity("error", "Нет выбранного фильтра")));
            else if (!sgou.isSize(body.getFilterId(), body.getX1(), body.getY1(), body.getX2(), body.getY2()))
                return ResponseEntity.ok().body(ObjectToJson.toJson(new CellEntity("error", "Не существуют данные ячейки")));
            else if (LocalDate.now().isBefore(body.getDate()))
                return ResponseEntity.ok().body(ObjectToJson.toJson(new CellEntity("error", "Дата изменения больше текущей даты")));
            else if (Arrays.stream(new String[]{"C", "S"}).noneMatch(x -> x.contains(body.getOperation())))
                return ResponseEntity.ok().body(ObjectToJson.toJson(new CellEntity("error", "Нет такой операции")));

            List<CellEntity> resp = new ArrayList<>();
            List<CellEntity> list = repo.findByParam(body.getFilterId(), body.getX1(), body.getX2(), body.getY1(), body.getY2(), LocalDate.now().toString());

            for (int i = body.getX1(); i <= body.getX2(); i++) {
                for (int j = body.getY1(); j <= body.getY2(); j++) {
                    int rowId1 = i, rowId2 = j;
                    CellEntity c = list.stream().filter(f -> f.getRowId1() == rowId1 && f.getRowId2() == rowId2 && f.getOperation().equals("C")).max(Comparator.comparing(CellEntity::getDate).thenComparing(CellEntity::getId)).orElse(null);
                    CellEntity s = list.stream().filter(f -> f.getRowId1() == rowId1 && f.getRowId2() == rowId2 && f.getOperation().equals("S")).max(Comparator.comparing(CellEntity::getDate).thenComparing(CellEntity::getId)).orElse(null);

                    if (c != null && c.getDate().isAfter(body.getDate()))
                        resp.add(new CellEntity(rowId1, rowId2, c, "error", "Обнаружено состояние с более поздней датой"));
                    else if (s != null && s.getDate().isAfter(body.getDate()))
                        resp.add(new CellEntity(rowId1, rowId2, s, "error", "Обнаружено состояние с более поздней датой"));
                    else {
                        if (body.getOperation().equals("C") && body.getValue() == 1) {
                            try {
                                repo.save(new CellEntity(rowId1, rowId2, body, user.getHq(), "C", 0));
                            } catch (Exception ex) {}

                            try {
                                resp.add(new CellEntity(rowId1, rowId2, body, user.getHq(), "C", 1));
                                repo.save(new CellEntity(rowId1, rowId2, body, user.getHq(), "C", 1));
                            } catch (Exception ex) {}

                            if (s != null && s.getValue() == 1) {
                                try {
                                    repo.save(new CellEntity(rowId1, rowId2, body, user.getHq(), "S", 0));
                                } catch (Exception ex) {}
                            }
                        } else {
                            CellEntity cs = new CellEntity(rowId1, rowId2, body, user.getHq(), body.getOperation(), body.getValue());
                            try {
                                repo.save(cs);
                                resp.add(cs);
                            } catch (Exception ex) {
                                resp.add(new CellEntity(rowId1, rowId2, cs, "error", "Такая запись уже существует"));
                            }
                        }
                    }
                }
            }

            List<CellEntity> newList = calc(repo.findByParam(body.getFilterId(), body.getX1(), body.getX2(), body.getY1(), body.getY2(), body.getDate().toString()));
            for (CellEntity ent1 : resp)
                if (ent1.getStatus().equals("ok"))
                    for (CellEntity ent2 : newList)
                        if (Objects.equals(ent1.getRowId1(), ent2.getRowId1()))
                            if (Objects.equals(ent1.getRowId2(), ent2.getRowId2())) {
                                ent1.setDate(ent2.getDate());
                                ent1.setOperation(ent2.getOperation());
                                ent1.setValue(ent2.getValue());
                            }
            log.info("Debug in method \"{}\", {}", "update", body);
            return ResponseEntity.ok().body(ObjectToJson.toJson(resp));
        } catch (Exception ex) {
            log.error("Error in method \"{}\", type error - {}!", "update", ex.toString());
            return ResponseEntity.internalServerError().body(new Gson().toJson(ex));
        }
    }

    public Object delete(CellRepository repo, CellEntity body, Sgou sgou) {
        try {
            int updatedRows = repo.deleteAllByParam(body.getFilterId(), body.getX1(), body.getX2(), body.getY1(), body.getY2(), body.getOperation(), body.getDate().toString());
            List<CellEntity> list = calc(repo.findByParam(body.getFilterId(), body.getX1(), body.getX2(), body.getY1(), body.getY2(), body.getDate().toString()));
            log.info("Debug in method \"{}\", Updated row {}, {}", "delete", updatedRows, list);
            return ResponseEntity.ok().body(ObjectToJson.toJson(list));
        } catch (Exception ex) {
            log.error("Error in and method \"{}\", type error - {}!", "delete", ex.toString());
            return ResponseEntity.internalServerError().body(new Gson().toJson(ex));
        }
    }

    private List<CellEntity> calc(List<CellEntity> entities) {
        return entities.stream()
                .filter(f -> f.getOperation().equals("C"))
                .map(c -> {
                    CellEntity s = entities
                            .stream()
                            .filter(f -> f.getRowId1().equals(c.getRowId1()) &&
                                    f.getRowId2().equals(c.getRowId2()) &&
                                    f.getOperation().equals("S"))
                            .findFirst()
                            .orElse(null);

                    if (s != null && s.getValue() == 1)
                        return s;
                    return c;
                })
                .collect(Collectors.toList());
    }
}
