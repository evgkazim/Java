package com.rusal.gou.auth;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.server.ResponseStatusException;

import java.util.Arrays;
import java.util.Base64;
import java.util.Date;

import static org.apache.logging.log4j.util.Strings.isEmpty;

@Aspect
@Component
@Slf4j
public class EtcAuthAspect {
    @Value("${etcAuth.secretKey:}")
    private String secretKey;
    @Value("${etcAuth.tokenName:etc_token}")
    private String tokenName;
    @Value("${etcAuth.rolePrefix:}")
    private String rolePrefix;

    @Around("@annotation(etcAuth)")
    public Object trace(ProceedingJoinPoint joinPoint, EtcAuth etcAuth) throws Throwable {
        final TokenUser user;
        if (isEmpty(secretKey))
            throw new Exception("Secret Key not found. Add property \"etcAuth.secretKey\" to app config.");
        try {
            user = getUserFromToken();
        } catch (Exception e) {
            log.error("Authorization error: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
        }
        if (!checkRole(user, etcAuth.roles()))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        final Object[] argsToModify = joinPoint.getArgs();
        for (int i = 0; i < argsToModify.length; i++)
            if (argsToModify[i].getClass().equals(TokenUser.class))
                argsToModify[i] = user;
        return joinPoint.proceed(argsToModify);
    }

    private boolean checkRole(TokenUser user, String[] roles) {
        boolean out = false;
        for (String a : user.getGroups())
            for (String b : roles)
                if (a.startsWith(rolePrefix))
                    if (a.substring(rolePrefix.length()).equals(b))
                        out = true;
        return out;
    }

    private TokenUser getUserFromToken() throws Exception {
        final HttpServletRequest servletRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
        final Cookie tokenCookie = Arrays.stream(servletRequest.getCookies()).filter(c -> c.getName().equals(tokenName)).findFirst().orElseThrow(null);
        final String token = new String(Base64.getDecoder().decode(tokenCookie.getValue()));
        final byte[] secretBytes = secretKey.getBytes();
        final Claims claims = Jwts.parser().setSigningKey(secretBytes).parseClaimsJws(token).getBody();
        if (claims.getExpiration().compareTo(new Date()) < 0)
            throw new Exception("Token expired!");
        return new ObjectMapper().readValue(claims.getSubject(), TokenUser.class);
    }
}

