package com.rusal.gou.model;

import com.rusal.gou.entity.*;
import com.rusal.gou.repository.FilterRepository;
import com.rusal.gou.repository.SeamRepository;
import com.rusal.gou.repository.SgouRepository;
import com.rusal.gou.repository.TypeFilterRepository;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.util.*;

@Slf4j
@Data
@NoArgsConstructor
public class Sgou {
    private Set<SgouEntity> sgou = new TreeSet<>(Comparator.comparing(SgouEntity::getObj_id));

    public Sgou(SgouRepository sgouRepository, FilterRepository filterRepository, TypeFilterRepository typeFilterRepository, SeamRepository seamRepository) {
        try {
            List<SgouEntity> sgouEntities = sgouRepository.findAll();
            List<FilterEntity> filterEntities = filterRepository.findAll();
            List<TypeFilterEntity> typeFilterEntities = typeFilterRepository.findAll();
            List<SeamEntity> seamEntities = seamRepository.findAll();

            for (SgouEntity s : sgouEntities) {
                for (FilterEntity f : filterEntities) {
                    if (s.getObj_id().equals(f.getParentId())) {
                        for (TypeFilterEntity t : typeFilterEntities) {
                            if (f.getTypeId().equals(t.getId()))
                                f.setType(t);
                        }
                        for (SeamEntity se : seamEntities) {
                            if (f.getId().equals(se.getFilter_id()))
                                f.getSeam().add(se);
                        }
                        s.getFilter().add(f);
                    }
                }
                this.sgou.add(s);
            }
        } catch (Exception ex) {
            log.error("Error in method \"{}\", type error - {}!", "init sgou", ex.toString());
            this.sgou = new TreeSet<>(Comparator.comparing(SgouEntity::getObj_id));
        }
    }

    public boolean isFilter(int filterId) {
        for (SgouEntity s : sgou)
            for (FilterEntity f : s.getFilter())
                if (f.getId() == filterId)
                    return true;
        return false;
    }

    public boolean isSize(int filterId, int x1, int y1, int x2, int y2) {
        for (SgouEntity s : sgou)
            for (FilterEntity f : s.getFilter())
                if (f.getId() == filterId) {
                    if (Math.max(x1, x2) > f.getType().getColCnt())
                        return false;
                    if (Math.max(y1, y2) > f.getType().getRowCnt())
                        return false;
                    if (Math.min(x1, Math.min(x2, Math.min(y1, y2))) < 1)
                        return false;
                }
        return true;
    }
}
