package com.rusal.gou.repository;

import com.rusal.gou.entity.ActionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.TreeSet;

@Repository
public interface StatRepository extends JpaRepository<ActionEntity, Integer> {
    @Query(value = "SELECT * FROM gou_data.cell_state WHERE FILTER_ID = ?1 AND DATE_STAMP BETWEEN TO_DATE(?2,'YYYY-MM-DD') AND TO_DATE(?3,'YYYY-MM-DD')", nativeQuery = true)
    TreeSet<ActionEntity> findByParam(String filterId, String dateStart, String dateEnd);
}
