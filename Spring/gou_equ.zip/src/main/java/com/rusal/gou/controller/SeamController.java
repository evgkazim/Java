package com.rusal.gou.controller;

import com.google.gson.Gson;
import com.rusal.gou.auth.EtcAuth;
import com.rusal.gou.auth.TokenUser;
import com.rusal.gou.entity.SeamEntity;
import com.rusal.gou.model.Sgou;
import com.rusal.gou.repository.FilterRepository;
import com.rusal.gou.repository.SeamRepository;
import com.rusal.gou.repository.SgouRepository;
import com.rusal.gou.repository.TypeFilterRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@CrossOrigin(originPatterns = "*", allowCredentials = "true")
@RequestMapping(path = "/seam", produces = "application/json")
public class SeamController {
    @Autowired private SgouRepository sgouRepository;
    @Autowired private FilterRepository filterRepository;
    @Autowired private TypeFilterRepository typeFilterRepository;
    @Autowired private SeamRepository seamRepository;
    @Autowired private Sgou sgou;

    @EtcAuth(roles = {"VIEW", "ADMIN"})
    @PostMapping
    public Object post(TokenUser user, @RequestBody SeamEntity body) {
        try {
            if (seamRepository.findByParam(body.getFilter_id(), body.getDate_trunc().toString(), body.getPoints()).size() > 0) {
                return ResponseEntity.ok().body("{\"command\":\"insert\",\"status\":\"skip\"}");
            } else {
                seamRepository.save(body);
                this.sgou = new Sgou(sgouRepository, filterRepository, typeFilterRepository, seamRepository);
                return ResponseEntity.ok().body("{\"command\":\"insert\",\"status\":\"ok\"}");
            }
        } catch (Exception ex) {
            log.error("Error in class \"{}\", method \"{}\", type error - {}!", this.getClass(), "update", ex.toString());
            return ResponseEntity.internalServerError().body(new Gson().toJson(ex));
        }
    }
}
