package com.rusal.gou.repository;

import com.rusal.gou.entity.CellEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface CellRepository extends JpaRepository<CellEntity, Integer> {
    @Query(value =
            "SELECT " +
                "MAX(ID) keep (Dense_Rank Last Order By DATE_TRUNC, DATE_STAMP) AS ID," +
                "FILTER_ID," +
                "ROW_ID1," +
                "ROW_ID2," +
                "OPER," +
                "MAX(DATE_TRUNC) AS DATE_TRUNC," +
                "MAX(VAL) keep (Dense_Rank Last Order By DATE_TRUNC, DATE_STAMP) AS VAL," +
                "MAX(USER_NAME) keep (Dense_Rank Last Order By DATE_TRUNC, DATE_STAMP) AS USER_NAME " +
            "FROM gou_data.cell_state " +
            "WHERE Filter_ID = ?1 AND DATE_TRUNC <= TO_DATE(?2,'YYYY-MM-DD')" +
            "GROUP BY FILTER_ID, ROW_ID1, ROW_ID2, OPER", nativeQuery = true)
    List<CellEntity> findByParam(String filterId, String date);

    @Query(value =
            "SELECT " +
                "MAX(ID) keep (Dense_Rank Last Order By DATE_TRUNC, DATE_STAMP) AS ID," +
                "FILTER_ID," +
                "ROW_ID1," +
                "ROW_ID2," +
                "OPER," +
                "MAX(DATE_TRUNC) AS DATE_TRUNC," +
                "MAX(VAL) keep (Dense_Rank Last Order By DATE_TRUNC, DATE_STAMP) AS VAL," +
                "MAX(USER_NAME) keep (Dense_Rank Last Order By DATE_TRUNC, DATE_STAMP) AS USER_NAME " +
            "FROM gou_data.cell_state " +
            "WHERE Filter_ID = ?1 AND Row_ID1 BETWEEN ?2 AND ?3 AND Row_ID2 BETWEEN ?4 AND ?5 AND DATE_TRUNC <= TO_DATE(?6,'YYYY-MM-DD')" +
            "GROUP BY FILTER_ID, ROW_ID1, ROW_ID2, OPER", nativeQuery = true)
    List<CellEntity> findByParam(int filterId, int rowId1Start, int rowId1End, int rowId2Start, int rowId2End, String date);

    @Query(value = "SELECT COUNT(*) FROM gou_data.cell_state WHERE FILTER_ID = ?1 AND ROW_ID1 = ?2 AND ROW_ID2 = ?3 AND OPER = ?4 AND VAL = ?5 AND DATE_TRUNC = TO_DATE(?6,'YYYY-MM-DD')", nativeQuery = true)
    int count(int filterId, int rowId1, int rowId2, String oper, int val, String date);

    @Modifying
    @Transactional
    @Query(value = "DELETE CellEntity WHERE Filter_ID = ?1 AND Row_ID1 BETWEEN ?2 AND ?3 AND Row_ID2 BETWEEN ?4 AND ?5 AND Oper = ?6 AND DATE_TRUNC = TO_DATE(?7,'YYYY-MM-DD')")
    int deleteAllByParam(int filterId, int rowId1Start, int rowId1End, int rowId2Start, int rowId2End, String oper, String date);
}
