package com.rusal.gou.entity;

import lombok.Data;
import javax.persistence.*;
import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

/**
 * Entity
 * @@Transient - пропуск переменной из запроса
 */

@Data
@Entity
@Table(schema = "gou_data", name = "plc_obj_ref")
public class SgouEntity {
    @Id
    private Integer obj_id;
    private String short_name;
    private String description;
    @Transient private Set<FilterEntity> filter = new TreeSet<>(Comparator.comparing(FilterEntity::getId));
}
