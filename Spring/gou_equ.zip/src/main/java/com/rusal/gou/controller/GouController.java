package com.rusal.gou.controller;

import com.rusal.gou.auth.TokenUser;
import com.google.gson.Gson;
import com.rusal.gou.auth.EtcAuth;
import com.rusal.gou.entity.SgouEntity;
import com.rusal.gou.model.Sgou;
import com.rusal.gou.utils.ObjectToJson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@RestController
@CrossOrigin(originPatterns = "*", allowCredentials = "true")
@RequestMapping(path = "gou", produces = "application/json")
public class GouController {
    @Autowired private Sgou sgou;

    @EtcAuth(roles = {"VIEW", "ADMIN"})
    @GetMapping("index")
    public Object index(TokenUser user, @RequestParam(defaultValue = "null") String id) {
        try {
            if (id.equals("null"))
                return ResponseEntity.ok().body(ObjectToJson.toJson(sgou.getSgou()));
            else
                return ResponseEntity.ok().body(ObjectToJson.toJson(sgou.getSgou().stream().filter(f -> Arrays.asList(id.split(",")).contains(String.valueOf(f.getObj_id()))).sorted(Comparator.comparing(SgouEntity::getObj_id)).collect(Collectors.toList())));
        } catch (Exception ex) {
            log.error("Error in class \"{}\", and method \"{}\", type error - {}!", this.getClass(), "/", ex.toString());
            return ResponseEntity.internalServerError().body(new Gson().toJson(ex));
        }
    }
}
