package com.rusal.gou.entity;

import com.fasterxml.jackson.annotation.JsonRawValue;
import lombok.Data;
import javax.persistence.*;

/**
 * Entity
 * @@Column - имя колонки в таблице
 * @@Transient - пропуск переменной из запроса
 * @@JsonRawValue - представить переменную String как объект Json (lib Jackson)
 */
@Data
@Entity
@Table(schema = "gou_data", name = "type_filter_ref")
public class TypeFilterEntity {
    @Id
    private Integer id;
    private String name;
    @Column(name = "col_cnt")
    private Integer colCnt;
    @Column(name = "row_cnt")
    private Integer rowCnt;
    @Column(name = "col_dir")
    private Integer colDir;
    @Column(name = "row_dir")
    private Integer rowDir;
    @JsonRawValue
    @Column(name = "list_lines")
    private String listLine;
}
