package com.rusal.gou.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Comparator;

import static javax.persistence.GenerationType.IDENTITY;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties({"id", "filter_id"})
@Table(schema = "gou_data", name = "cell_state")
public class ActionEntity implements Comparable<ActionEntity> {
    @Id
    @GeneratedValue(strategy = IDENTITY)
    private Integer id;
    private int filter_id;
    private int row_id1;
    private int row_id2;
    private String oper;
    private String date_trunc;
    private int val;
    private String date_stamp;
    private String user_name;

    @Override
    public int compareTo(ActionEntity o) {
        return Comparator
                .comparing(ActionEntity::getDate_stamp)
                .thenComparing(ActionEntity::getFilter_id)
                .thenComparing(ActionEntity::getRow_id1)
                .thenComparing(ActionEntity::getRow_id2)
                .thenComparing(ActionEntity::getOper)
                .compare(this, o);
    }
}
