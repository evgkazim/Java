package com.rusal.gou.config;

import com.rusal.gou.model.Sgou;
import com.rusal.gou.repository.FilterRepository;
import com.rusal.gou.repository.SeamRepository;
import com.rusal.gou.repository.SgouRepository;

import com.rusal.gou.repository.TypeFilterRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class GouConfig {
    @Autowired private SgouRepository sgouRepository;
    @Autowired private FilterRepository filterRepository;
    @Autowired private TypeFilterRepository typeFilterRepository;
    @Autowired private SeamRepository seamRepository;

    @Bean
    public Sgou sgou() {
        try {
            return new Sgou(sgouRepository, filterRepository, typeFilterRepository, seamRepository);
        } catch (Exception ex) {
            log.error("Error in method \"{}\", type error - {}!", "init sgou", ex.toString());
            return new Sgou();
        }
    }
}
