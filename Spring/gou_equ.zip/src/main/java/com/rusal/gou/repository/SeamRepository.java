package com.rusal.gou.repository;

import com.rusal.gou.entity.SeamEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SeamRepository extends JpaRepository<SeamEntity, Long> {
    @Query(value = "SELECT * FROM gou_data.seams WHERE FILTER_ID = ?1 AND DATE_TRUNC = TO_DATE(?2,'YYYY-MM-DD') AND POINTS = ?3", nativeQuery = true)
    List<SeamEntity> findByParam(int filterId, String dateTrunc, String points);
}