package com.rusal.gou.controller;

import com.google.gson.Gson;
import com.rusal.gou.auth.EtcAuth;
import com.rusal.gou.auth.TokenUser;
import com.rusal.gou.repository.StatRepository;
import com.rusal.gou.utils.ObjectToJson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@Slf4j
@RestController
@CrossOrigin(originPatterns = "*", allowCredentials = "true")
@RequestMapping(path = "/action", produces = "application/json")
public class ActionController {
    @Autowired
    private StatRepository repo;

    @EtcAuth(roles = {"VIEW", "ADMIN"})
    @GetMapping
    public Object get(TokenUser user, @RequestParam Map<String, String> param) {
        try {
            return ResponseEntity.ok().body(ObjectToJson.toJson(repo.findByParam(param.get("id"), param.get("date1"), param.get("date2"))));
        } catch (Exception ex) {
            log.error("Error method \"{}\", type error - {}!", "get", ex.toString());
            return ResponseEntity.internalServerError().body(new Gson().toJson(ex));
        }
    }
}
