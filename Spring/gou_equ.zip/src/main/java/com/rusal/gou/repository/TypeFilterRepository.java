package com.rusal.gou.repository;

import com.rusal.gou.entity.TypeFilterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TypeFilterRepository extends JpaRepository<TypeFilterEntity, Integer> {
}
