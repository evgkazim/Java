## Gou equ

#### gou
- /gou_equ/gou/index
- /gou_equ/gou/index/?id=`81` or /gou_equ/?id=`81,82`

#### cell GET
 - /gou_equ/cell?id=`1`&date=`2023-03-20` 
#### ������ ������
```json
[
    {
        "id": 1,
        "row_id1": 1,
        "row_id2": 1,
        "operation": "C",
        "value": 0,
        "date": "2023-04-05",
        "user": "test"
    },
    ...
    {
        "id": 2,
        "row_id1": 1,
        "row_id2": 2,
        "operation": "C",
        "value": 1,
        "date": "2021-02-01",
        "user": "test"
    }
]
```
#### Cell POST
 - /gou_equ/cell
#### ������ body
```json
{
  "filter_id": 1,
  "x1": 15,
  "y1": 15,
  "x2": 20,
  "y2": 20,
  "operation": "C",
  "date": "2023-04-28",
  "value": 0
}
```
#### ������ ������
```json
[
  {
    "id": 1,
    "row_id1": 1,
    "row_id2": 1,
    "operation": "C",
    "value": 0,
    "date": "2023-04-28",
    "user": "test",
    "status": "ok"
  },
  ...
  {
    "id": 2,
    "row_id1": 1,
    "row_id2": 1,
    "operation": "C",
    "value": 0,
    "date": "2023-04-28",
    "user": "test",
    "status": "error",
    "message": "������������ ������� � ���������"
  }
]
```
#### Cell DELETE
 - delete /gou_equ/cell
#### ������ body
```json
{
  "filter_id": 1,
  "x1": 15,
  "y1": 15,
  "x2": 20,
  "y2": 20,
  "operation": "S",
  "date": "2023-04-27"
}
```
#### ������ ������
```json
[
    {
        "id": 1,
        "row_id1": 1,
        "row_id2": 1,
        "operation": "C",
        "value": 1,
        "date": "2021-02-01",
        "user": "test"
    },
    ...
    {
        "id": 2,
        "row_id1": 1,
        "row_id2": 1,
        "operation": "C",
        "value": 1,
        "date": "2021-02-01",
        "user": "test"
    }
]
```
#### Seam POST
- /gou_equ/seam
#### ������ body
```json
{
  "filter_id":1,
  "date_trunc":"2023-04-02",
  "points":"[[1,8],[1,9]]",
  "user_name":"test"
}
```
#### ������ ������
```json
{
  "command": "insert",
  "status": "skip"
}
OR
{
  "command": "insert",
  "status": "ok"
}
```
#### EtcAuth
```auth
    prefix NKAZ-GSG-GOUEQU-
    
    1. NKAZ-GSG-GOUEQU-VIEW
    2. NKAZ-GSG-GOUEQU-ADMIN
```
<details><summary>A dropdown list for markdown</summary>

1. First item must be preceeded with an empty line.
1. Markdown renders **perfectly**.
1. Extra item.

</details>